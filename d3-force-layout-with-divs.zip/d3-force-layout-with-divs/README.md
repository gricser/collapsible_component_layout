# D3 force layout with divs

A Pen created on CodePen.io. Original URL: [https://codepen.io/gricser/pen/ExMrzrB](https://codepen.io/gricser/pen/ExMrzrB).

Forked: http://bl.ocks.org/1021841
Doc: https://github.com/mbostock/d3/wiki/Force-Layout
Added: Comments.
https://github.com/mbostock/d3/wiki/API-Reference